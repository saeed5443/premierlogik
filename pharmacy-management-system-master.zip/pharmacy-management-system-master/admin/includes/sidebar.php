<ul class="nav nav-sidebar">
    <li><a href="dashboard.php">Overview</a></li>
</ul>
<hr>
<ul class="nav nav-sidebar">
    <li><a href="add_medicine.php">Add medicine</a></li>
    <li><a href="add_group.php">Add group</a></li>
    <li><a href="add_brand.php">Add brand</a></li>
</ul>
<hr>
<ul class="nav nav-sidebar">
    <li><a href="placement.php">Organize</a></li>
    <li><a href="manage.php">Manage</a></li>
</ul>
<footer class="footer">
    <p class="copyright">&copy; MoonStar | 2016</p>
</footer>