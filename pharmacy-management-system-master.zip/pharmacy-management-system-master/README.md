# Pharmacy Management System
Pharmacy Management System - A PHP project for pharmacy store to manage and find the products/medicines.

# Purpose
Project to lear PHP and Database throughout my Database course.
